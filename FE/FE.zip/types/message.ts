export type MessageRole =
  | "user"
  | "assistant"
  | "system";

export interface ChatMessage {
  id: string;

  role: MessageRole;

  content: string;

  createdAt?: Date;

  updatedAt?: Date;

  model?: string;
}